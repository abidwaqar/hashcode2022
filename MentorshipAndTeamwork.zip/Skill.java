public class Skill {
    String name;
    int level;

    public Skill(String name, int level) {
        this.name = name;
        this.level = level;
    }
}
public class Role {
    String skillName;
    int requiredLevel;

    public Role(String skillName, int requiredLevel) {
        this.skillName = skillName;
        this.requiredLevel = requiredLevel;
    }
}
import java.util.*;

public class Output {
    String projectName;
    List<String> contributors;

    public Output(String projectName) {
        this.projectName = projectName;
        contributors = new ArrayList<>();
    }
}